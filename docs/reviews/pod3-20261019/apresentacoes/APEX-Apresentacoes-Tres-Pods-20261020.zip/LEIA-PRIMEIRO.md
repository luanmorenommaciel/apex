# Apresentações APEX — versão de 20/10/2026

Esta pasta reúne as versões atuais. As versões anteriores em outras pastas permanecem como histórico. Publicação documental nas PRs #183, #187 e #189; os links de acesso estão nas issues #181, #188 e #190. A publicação em branch não significa integração na main.

| Apresentação | Slides | PowerPoint | Navegador | Roteiro |
|---|---:|---|---|---|
| Pod 1 / Front-end | 10 | [APEX-Pod1-Front-20261020.pptx](APEX-Pod1-Front-20261020.pptx) | [Abrir](APRESENTAR-POD1.html) | [Fala](ROTEIRO-POD1.md) |
| Pod 2 / Engine | 10 | [APEX-Pod2-Engine-20261020.pptx](APEX-Pod2-Engine-20261020.pptx) | [Abrir](APRESENTAR-POD2.html) | [Fala](ROTEIRO-POD2.md) |
| Pod 3 / Serve | 20 | [APEX-Pod3-Serve-20261020-v4.pptx](APEX-Pod3-Serve-20261020-v4.pptx) | [Abrir](APRESENTAR-POD3.html) | [Fala](ROTEIRO-POD3.md) |
| APEX / três pods | 12 | [APEX-Executiva-Tres-Pods-20261020.pptx](APEX-Executiva-Tres-Pods-20261020.pptx) | [Abrir](APRESENTAR-EXECUTIVA.html) | [Fala](ROTEIRO-EXECUTIVA.md) |

Sugestão: apresentar a executiva em 10–15 minutos e usar os arquivos de cada pod para aprofundar. Pod 3 tem slides de apoio com minutas e histórico.

As notas incluem fontes e contexto para a fala. A documentação reflete a revalidação de 20/10/2026; cada relato de teste conserva seu próprio corte. Implementado na branch, integrado e aceito pelo time continuam estados distintos.

O Pod 3 v4 substitui a v3 para apresentação. Os arquivos v2/v3 anteriores continuam históricos.

## Correções incorporadas

Reconhecimento das implementações/provas #182/#185/#153; reconciliação de #172 antes de repetir prova; autoria compartilhada; nomes MCP; distinção de encerramento e merge; reutilização #164; correções de contagem/cortes e alcance documental dos 525 IDs. Sem novo aceite funcional ou execução de produto.
